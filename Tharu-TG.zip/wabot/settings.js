// Runtime settings = config.js defaults + whatever the owner changed in chat (settings.json)
const fs = require('fs')
const path = require('path')
const config = require('./config')

const file = path.join(__dirname, 'settings.json')

let saved = {}
try {
  saved = JSON.parse(fs.readFileSync(file, 'utf8'))
} catch {}

const settings = {
  features: { ...config.features, ...(saved.features || {}) },
  statusEmoji: Array.isArray(saved.statusEmoji) && saved.statusEmoji.length ? saved.statusEmoji : config.statusEmoji
}

function save() {
  fs.writeFileSync(file, JSON.stringify(settings, null, 2))
}

module.exports = { settings, save }
