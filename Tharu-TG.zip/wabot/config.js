// Edit this file, then start the bot with: npm start
module.exports = {
  botName: 'Tharu-TG',

  // Command prefix. ".ping", ".menu", ...
  prefix: '.',

  // Your personal number(s): country code + number, digits only (no +, no spaces).
  // Example: '94771234567'
  owner: ['94XXXXXXXXX'],

  // Optional: the BOT number (the spare number the bot runs on).
  // If set, you get an 8-character pairing code instead of a QR code.
  pairingNumber: '',

  // Folder where the login session is stored. Keep it private: it is full access to the account.
  sessionDir: 'session',

  // Defaults. The owner can change these in chat (.online, .antidelete, ...);
  // changes are saved in settings.json.
  features: {
    alwaysOnline: true,
    antiDelete: true,
    statusView: true,
    statusReact: true
  },

  statusEmoji: ['😂', '🔥', '❤️', '👍'],

  antiDelete: {
    // 'owner' = forward the deleted message to your chat, 'chat' = repost in the same chat
    sendTo: 'owner',
    maxCached: 300,
    maxMediaMB: 10
  },

  // Random delay before viewing / reacting to a status, so it looks natural
  statusDelay: { minMs: 1500, maxMs: 5000 }
}
