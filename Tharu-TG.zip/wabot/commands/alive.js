module.exports = {
  name: 'alive',
  description: 'Check bot status',
  async run({ reply, uptime, settings, config }) {
    const s = Math.floor(uptime / 1000)
    const h = Math.floor(s / 3600)
    const mi = Math.floor((s % 3600) / 60)
    const sec = s % 60
    const on = (v) => (v ? 'ON ✅' : 'OFF ❌')
    const f = settings.features
    await reply(
      `*${config.botName} is online* ✅\n` +
        `Uptime: ${h}h ${mi}m ${sec}s\n\n` +
        `Always online: ${on(f.alwaysOnline)}\n` +
        `Anti-delete: ${on(f.antiDelete)}\n` +
        `Status view: ${on(f.statusView)}\n` +
        `Status react: ${on(f.statusReact)}`
    )
  }
}
