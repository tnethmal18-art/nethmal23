// Owner commands: .online  .antidelete  .statusview  .statusreact  .settings  .setemoji
const FEATURES = {
  online: ['alwaysOnline', 'Always online'],
  antidelete: ['antiDelete', 'Anti-delete'],
  statusview: ['statusView', 'Status auto-view'],
  statusreact: ['statusReact', 'Status emoji react']
}

const toggles = Object.entries(FEATURES).map(([name, [key, label]]) => ({
  name,
  description: `${label} on/off`,
  ownerOnly: true,
  async run({ args, reply, settings, save, config, applyPresence }) {
    const value = (args[0] || '').toLowerCase()
    if (value !== 'on' && value !== 'off') {
      return reply(`Usage: ${config.prefix}${name} on|off  (now: ${settings.features[key] ? 'on' : 'off'})`)
    }
    settings.features[key] = value === 'on'
    save()
    if (key === 'alwaysOnline') applyPresence()
    await reply(`${label} is now ${value.toUpperCase()}`)
  }
}))

const showSettings = {
  name: 'settings',
  description: 'Show current settings',
  ownerOnly: true,
  async run({ reply, settings, config }) {
    const on = (v) => (v ? 'ON ✅' : 'OFF ❌')
    const f = settings.features
    await reply(
      `*Settings*\n` +
        `Always online: ${on(f.alwaysOnline)}\n` +
        `Anti-delete: ${on(f.antiDelete)} (sends to: ${config.antiDelete.sendTo})\n` +
        `Status view: ${on(f.statusView)}\n` +
        `Status react: ${on(f.statusReact)}\n` +
        `Status emojis: ${settings.statusEmoji.join(' ')}`
    )
  }
}

const setEmoji = {
  name: 'setemoji',
  description: 'Set status reaction emojis, e.g. .setemoji 😂 🔥 ❤️',
  ownerOnly: true,
  async run({ args, reply, settings, save, config }) {
    const emojis = args.filter((a) => /\p{Extended_Pictographic}/u.test(a)).slice(0, 10)
    if (!emojis.length) return reply(`Usage: ${config.prefix}setemoji 😂 🔥 ❤️`)
    settings.statusEmoji = emojis
    save()
    await reply(`Status emojis set: ${emojis.join(' ')}`)
  }
}

module.exports = [...toggles, showSettings, setEmoji]
