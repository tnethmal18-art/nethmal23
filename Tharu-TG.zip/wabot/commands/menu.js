module.exports = {
  name: 'menu',
  aliases: ['help'],
  description: 'Show all commands',
  async run({ reply, commandList, config }) {
    const lines = commandList.map((c) => `${config.prefix}${c.name} - ${c.description}${c.ownerOnly ? ' 🔒' : ''}`)
    await reply(`*${config.botName.toUpperCase()} MENU*\n\n${lines.join('\n')}\n\n🔒 = owner only`)
  }
}
