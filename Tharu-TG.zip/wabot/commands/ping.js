module.exports = {
  name: 'ping',
  description: 'Check bot speed',
  async run({ m, reply }) {
    const ms = Math.max(0, Date.now() - Number(m.messageTimestamp) * 1000)
    await reply(`Pong! 🏓 ${ms} ms`)
  }
}
