const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  proto
} = require('@whiskeysockets/baileys')
const pino = require('pino')
const qrcode = require('qrcode-terminal')
const fs = require('fs')
const path = require('path')

const config = require('./config')
const { settings } = require('./settings')
const { save } = require('./settings')
const { unwrap, getText, sleep, bareNumber } = require('./lib/helpers')
const { cacheMessage, handleRevoke } = require('./lib/antidelete')
const { handleStatus } = require('./lib/status')

const logger = pino({ level: 'silent' })
const startedAt = Date.now()

// ---------- load commands from ./commands ----------
const commands = new Map()
const commandList = []
for (const file of fs.readdirSync(path.join(__dirname, 'commands')).filter((f) => f.endsWith('.js'))) {
  for (const cmd of [].concat(require(`./commands/${file}`))) {
    commandList.push(cmd)
    commands.set(cmd.name, cmd)
    for (const alias of cmd.aliases || []) commands.set(alias, cmd)
  }
}

// ---------- always online ----------
let presenceTimer = null
function applyPresence(sock) {
  clearInterval(presenceTimer)
  presenceTimer = null
  if (settings.features.alwaysOnline) {
    const ping = () => sock.sendPresenceUpdate('available').catch(() => {})
    ping()
    presenceTimer = setInterval(ping, 45_000) // the "online" status expires, so refresh it
  } else {
    sock.sendPresenceUpdate('unavailable').catch(() => {})
  }
}

// ---------- commands ----------
// Note: replies must never start with the prefix, or the bot could answer itself.
async function handleCommand(sock, m) {
  const { msg } = unwrap(m.message)
  const text = getText(msg || {})
  if (!text.startsWith(config.prefix)) return

  const body = text.slice(config.prefix.length).trim()
  if (!/^\p{L}/u.test(body)) return // ignore "...", ".5", ". hello"

  const args = body.split(/\s+/)
  const name = args.shift().toLowerCase()
  const cmd = commands.get(name)
  if (!cmd) return

  const from = m.key.remoteJid
  const sender = bareNumber(m.key.participant || from)
  const isOwner = m.key.fromMe || config.owner.includes(sender)
  const reply = (t) => sock.sendMessage(from, { text: t }, { quoted: m })

  if (cmd.ownerOnly && !isOwner) return reply('⛔ Owner only.')

  try {
    await cmd.run({
      sock,
      m,
      from,
      sender,
      isOwner,
      args,
      text: args.join(' '),
      reply,
      settings,
      save,
      config,
      commandList,
      uptime: Date.now() - startedAt,
      applyPresence: () => applyPresence(sock)
    })
  } catch (e) {
    console.error(`${config.prefix}${name} failed:`, e)
    reply('⚠️ Command failed.').catch(() => {})
  }
}

// ---------- connection ----------
async function start() {
  const sessionPath = path.join(__dirname, config.sessionDir)
  const { state, saveCreds } = await useMultiFileAuthState(sessionPath)
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    version,
    auth: state,
    logger,
    browser: [config.botName, 'Chrome', '1.0.0'],
    markOnlineOnConnect: settings.features.alwaysOnline,
    syncFullHistory: false
  })

  sock.ev.on('creds.update', saveCreds)

  // Link with an 8-character code instead of a QR code
  if (!sock.authState.creds.registered && config.pairingNumber) {
    await sleep(3000)
    const code = await sock.requestPairingCode(config.pairingNumber.replace(/\D/g, ''))
    console.log(`\nPairing code: ${code}`)
    console.log('WhatsApp > Settings > Linked devices > Link with phone number instead\n')
  }

  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr && !config.pairingNumber) {
      console.log('Scan this QR code: WhatsApp > Settings > Linked devices > Link a device')
      qrcode.generate(qr, { small: true })
    }

    if (connection === 'open') {
      console.log(`✅ ${config.botName} connected as ${sock.user.id}`)
      applyPresence(sock)
    }

    if (connection === 'close') {
      clearInterval(presenceTimer)
      const code = lastDisconnect?.error?.output?.statusCode
      if (code === DisconnectReason.loggedOut) {
        console.log('Logged out of WhatsApp. Clearing the old session; link the device again.')
        fs.rmSync(sessionPath, { recursive: true, force: true })
      } else {
        console.log(`Connection closed (${code}). Reconnecting...`)
      }
      setTimeout(start, 3000)
    }
  })

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    for (const m of messages) {
      try {
        if (!m.message) continue

        if (m.key.remoteJid === 'status@broadcast') {
          await handleStatus(sock, m)
          continue
        }

        const protocol = m.message.protocolMessage
        if (protocol && protocol.type === proto.Message.ProtocolMessage.Type.REVOKE) {
          await handleRevoke(sock, protocol)
          continue
        }

        if (type !== 'notify') continue
        await cacheMessage(sock, m)
        await handleCommand(sock, m)
      } catch (e) {
        console.error('message handler error:', e)
      }
    }
  })
}

process.on('unhandledRejection', (e) => console.error('unhandledRejection:', e))
process.on('uncaughtException', (e) => console.error('uncaughtException:', e))

start()
