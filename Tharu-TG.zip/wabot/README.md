# Tharu-TG WhatsApp Bot

Baileys-based WhatsApp bot with the `.` prefix, always-online, anti-delete, and status auto-view + emoji react.

## Setup

1. Install Node.js 18 or newer.
2. Open `config.js` and set `owner` to your own number (country code, digits only).
   Optionally set `pairingNumber` to the bot's number to link with a code instead of a QR.
3. Install and start:

   ```bash
   npm install
   npm start        # runs under PM2 as "Tharu-TG"
   ```

4. Link the bot: scan the QR code (or enter the pairing code) in
   WhatsApp > Settings > Linked devices on the **spare number** the bot will use.

`npm stop` and `npm restart` control the PM2 process. To start automatically after a server reboot, run `pm2 save` and `pm2 startup` once.

## Commands (prefix `.`)

| Command | Who | What it does |
|---|---|---|
| `.ping` | everyone | Check speed |
| `.alive` | everyone | Uptime and feature status |
| `.menu` | everyone | List commands |
| `.online on/off` | owner | Always-online presence |
| `.antidelete on/off` | owner | Recover deleted messages |
| `.statusview on/off` | owner | Auto-view statuses |
| `.statusreact on/off` | owner | Auto-react to statuses |
| `.setemoji 😂 🔥 ❤️` | owner | Change the reaction emojis |
| `.settings` | owner | Show current settings |

Settings changed in chat are saved in `settings.json`. Defaults live in `config.js`.

## Adding a command

Create a file in `commands/`:

```js
module.exports = {
  name: 'hello',
  description: 'Say hello',
  // ownerOnly: true,
  async run({ reply }) {
    await reply('Hello! 👋')
  }
}
```

Restart the bot and it appears in `.menu`.

## Notes

- **Ban risk:** this uses an unofficial library and goes against WhatsApp's Terms of Service. Use a spare number, never your main one.
- **Keep `session/` private.** Anyone with that folder has full access to the bot's WhatsApp account. It is in `.gitignore`.
- **Anti-delete** only recovers messages deleted "for everyone" that arrived while the bot was running. Deleted messages go to the owner's chat by default (`antiDelete.sendTo` in `config.js`). View-once media is intentionally never saved.
- **Always online** with `markOnlineOnConnect` can stop push notifications on a phone that uses the same number. On a dedicated bot number this does not matter.
- **Owner check** compares the sender's number with `owner`. If owner commands are ignored in a group, send them in a private chat with the bot.
- Several packages in `package.json` (`path`, `util`, `vm`, `punycode`) duplicate Node built-ins, and `express`, `api-dylux`, `megajs`, `ffmpeg*` and the ID3 packages are not used by the current code. They are safe to remove if you do not add features that need them. Pinning `express` to a version instead of `latest` avoids surprise upgrades.
